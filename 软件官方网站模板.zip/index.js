const androidLink = `Android.apk`;
const windowsLink = `Windows.exe`;
const appStoreLink = ``;

const getUserDevice = () => {
  const ua = navigator.userAgent;
  const isAndroid = ua.indexOf('Android') > -1;
  const isIOS = !!ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
  const isMac = ua.indexOf('Mac OS') > -1;
  const isWindows = ua.indexOf('Windows') > -1;
  if (isAndroid) {
    return 'android';
  }
  if (isIOS) {
    return 'ios';
  }
  if (isMac) {
    return 'mac';
  }
  return 'windows';
};

document.addEventListener('DOMContentLoaded', () => {
  const downloadLink = document.querySelector('.btn-download');
  const device = getUserDevice();

  if (device === 'android') {
    downloadLink.href = androidLink;
    downloadLink.innerHTML = '<i class="fab fa-android"></i> Android 下载';
  } else if (device === 'ios') {
    downloadLink.href = appStoreLink;
    downloadLink.innerHTML = '<i class="fab fa-apple"></i> iOS 下载';
  } else if (device === 'mac') {
    downloadLink.href = appStoreLink;
    downloadLink.innerHTML = '<i class="fab fa-apple"></i> macOS 下载';
  } else {
    downloadLink.href = windowsLink;
    downloadLink.innerHTML = '<i class="fab fa-windows"></i> Windows 下载';
  }

  downloadLink.addEventListener('click', sendDownloadTrackingData);
});

document.addEventListener('DOMContentLoaded', function () {
  const h5Download = document.querySelector('.h5-top-right');

  h5Download.addEventListener('click', () => {
    const device = getUserDevice();
    sendDownloadTrackingData();
    if (device === 'ios' || device === 'mac') {
      window.open(appStoreLink, '_blank');
    } else if (device === 'android') {
      window.open(androidLink, '_blank');
    } else {
      window.open(windowsLink, '_blank');
   document.addEventListener('DOMContentLoaded', () => {
  const windowsDeviceItem = document.querySelector('.device-item i.fa-windows').parentElement;
  windowsDeviceItem.href = 'Windows.exe';
  windowsDeviceItem.addEventListener('click', () => {
    window.location.href = 'Windows.exe';
  });
});   
      
    }
  });
});

